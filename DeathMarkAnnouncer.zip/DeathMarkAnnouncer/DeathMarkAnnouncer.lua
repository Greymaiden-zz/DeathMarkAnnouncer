local DEBUFF_TO_TRACK = "Death Mark"

local frame = CreateFrame("Frame")
frame:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_CREATURE_DAMAGE") 
frame:RegisterEvent("PLAYER_REGEN_DISABLED") -- Fires the exact microsecond YOU enter combat
frame:RegisterEvent("PLAYER_REGEN_ENABLED")  -- Fires when you leave combat
frame:RegisterEvent("PLAYER_TARGET_CHANGED")

local lastAnnounceTime = 0
local COOLDOWN_BUFFER = 4 
local justEnteredCombat = false

-- Dynamic sequential talent index lookup for genuine 1.12 talents
local function IsDeathMarkActive()
    for tab = 1, 3 do
        for id = 1, 30 do
            local name, _, _, _, rank = GetTalentInfo(tab, id)
            if name and name == DEBUFF_TO_TRACK then
                if rank and rank > 0 then
                    return true
                else
                    return false
                end
            end
        end
    end
    return false
end

frame:SetScript("OnEvent", function()
    if event == "PLAYER_TARGET_CHANGED" then
        lastAnnounceTime = 0
        return
    end

    -- STEP 1: Catch when YOU physically engage a mob out of stealth
    if event == "PLAYER_REGEN_DISABLED" then
        justEnteredCombat = true
        return
    end

    if event == "PLAYER_REGEN_ENABLED" then
        justEnteredCombat = false
        return
    end

    -- STEP 2: Process the shared server affliction log line
    if event == "CHAT_MSG_SPELL_PERIODIC_CREATURE_DAMAGE" and arg1 then
        -- Dynamic pattern string lookup: parses out the literal name of the boss
        local _, _, logTarget = string.find(arg1, "(.+) is afflicted by " .. DEBUFF_TO_TRACK .. "%.")
        
        if logTarget then
            -- OWNER GATE: Verifies that YOU were the one who initiated combat to open the fight
            -- Other rogues in your group pulling or breaking stealth will never trigger your REGEN flags
            if justEnteredCombat then
                
                -- Live Talent Gate
                if IsDeathMarkActive() then
                    
                    -- Target Match Verification
                    if UnitExists("target") and UnitName("target") == logTarget then
                        
                        -- NATIVE 1.12 RAID BOSS FILTER
                        local inRaidGroup = GetNumRaidMembers() > 0
                        local targetLevel = UnitLevel("target")
                        local targetClass = UnitClassification("target")
                        
                        local isRaidBoss = inRaidGroup and (
                            (targetLevel == -1) or 
                            (targetLevel == 63) or 
                            (targetClass == "worldboss")
                        )
                        
                        if isRaidBoss then
                            -- Cooldown safety barrier
                            if GetTime() - lastAnnounceTime > COOLDOWN_BUFFER then
                                SendChatMessage(DEBUFF_TO_TRACK .. " applied to " .. logTarget .. " for 25s!", "YELL")
                                lastAnnounceTime = GetTime()
                                justEnteredCombat = false -- Consume flag immediately
                            end
                        end
                        
                    end
                end
                
            end
        end
    end
end)